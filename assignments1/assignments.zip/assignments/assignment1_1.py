# Write Fun() to print Hello from Fun
def Fun():
    """Print a default string"""
    print("Hello from Fun")
def main():
    Fun()
if (__name__ == "__main__"):
    main()