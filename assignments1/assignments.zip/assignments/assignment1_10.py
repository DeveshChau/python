# Display length of given string
def strLen(value):
    """Print length of given string"""
    print(len(value))
def main():
    name = input("Enter your name: ")
    strLen(name)

if __name__=="__main__":
    main()