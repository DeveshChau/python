# Display first 10 even number
def display10Even():
    """Print first 10 even numbers"""
    for i in range(2,21,2):
        print(i)
def main():
    display10Even()
if __name__ == "__main__":
    main()  