# Print Marvellous 5 times
def printName(value):
    """Print given name 5 times"""
    for i in range(5):
        print(value)
def main():
    printName("Marvellous")
if (__name__ == "__main__"):
    main()