# Display from 10 to 1
def display10to1():
    i = 10
    while(i > 0):
        print(i)
        i = i - 1
def main():
    display10to1()
if __name__ == "__main__":
    main()